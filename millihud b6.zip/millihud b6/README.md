# Millihud
A custom hud for TF2 based on deli hud and peach hud
==================================================================================
Credit goes to deli, peach, and hypno. I couldnt have made this without their huds.

===================================================================================

If you have access to this hud, please do not share it without my permission. I dont know if I want
to release this and the current version has my rcon and server connect BUILT IN. Please respect me
trusting you with access by not sharing.

please leave any and all feedback on github! this way I can compile it and fix all of the MANY bugs.
https://github.com/catsmillionaire/Millihud/issues


Thank you all for bug testing for me! I really appreciate it! if you need any assistance/ want any edits
for a personalized hud, please dm me on discord! hexuu#5343

ily cuties owo
